import React from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import { Sidebar } from './components/Layout/Sidebar';
import { Header } from './components/Layout/Header';
import { Dashboard } from './components/Dashboard/Dashboard';
import { AccountsList } from './components/Accounts/AccountsList';
import { GroupsManagement } from './components/Groups/GroupsManagement';
import { CentralInbox } from './components/Inbox/CentralInbox';
import { TasksManagement } from './components/Tasks/TasksManagement';
import { AlertsCenter } from './components/Alerts/AlertsCenter';
import { AnalyticsDashboard } from './components/Analytics/AnalyticsDashboard';

function AppContent() {
  const { activeSection } = useApp();

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'accounts':
        return <AccountsList />;
      case 'groups':
        return <GroupsManagement />;
      case 'inbox':
        return <CentralInbox />;
      case 'tasks':
        return <TasksManagement />;
      case 'alerts':
        return <AlertsCenter />;
      case 'analytics':
        return <AnalyticsDashboard />;
      case 'settings':
        return (
          <div className="p-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Settings</h1>
            <p className="text-gray-600">Settings panel coming soon...</p>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Header />
        <main className="flex-1 overflow-auto">
          {renderActiveSection()}
        </main>
      </div>
    </div>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;