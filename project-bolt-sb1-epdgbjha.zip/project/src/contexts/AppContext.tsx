import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Account, Group, Email, Task, Alert, Analytics } from '../types';

interface AppContextType {
  // Accounts
  accounts: Account[];
  addAccount: (account: Omit<Account, 'id'>) => void;
  updateAccount: (id: string, updates: Partial<Account>) => void;
  deleteAccount: (id: string) => void;
  
  // Groups
  groups: Group[];
  addGroup: (group: Omit<Group, 'id'>) => void;
  updateGroup: (id: string, updates: Partial<Group>) => void;
  deleteGroup: (id: string) => void;
  
  // Emails
  emails: Email[];
  markAsRead: (emailId: string) => void;
  starEmail: (emailId: string) => void;
  
  // Tasks
  tasks: Task[];
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  
  // Alerts
  alerts: Alert[];
  markAlertAsRead: (alertId: string) => void;
  
  // Analytics
  analytics: Analytics;
  
  // UI State
  activeSection: string;
  setActiveSection: (section: string) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock data
const mockAccounts: Account[] = [
  {
    id: '1',
    email: 'admin@company.com',
    name: 'Admin Account',
    isActive: true,
    groupId: '1',
    lastSync: new Date(),
    messageCount: 247,
    oauthStatus: 'connected',
  },
  {
    id: '2',
    email: 'sales@company.com',
    name: 'Sales Team',
    isActive: true,
    groupId: '1',
    lastSync: new Date(Date.now() - 30000),
    messageCount: 156,
    oauthStatus: 'connected',
  },
  {
    id: '3',
    email: 'support@company.com',
    name: 'Customer Support',
    isActive: true,
    groupId: '2',
    lastSync: new Date(Date.now() - 60000),
    messageCount: 892,
    oauthStatus: 'pending',
  },
];

const mockGroups: Group[] = [
  {
    id: '1',
    name: 'Management Team',
    description: 'Executive and management accounts',
    accountIds: ['1', '2'],
    color: 'bg-blue-500',
    createdAt: new Date(),
    isActive: true,
  },
  {
    id: '2',
    name: 'Customer Service',
    description: 'Customer support and service accounts',
    accountIds: ['3'],
    color: 'bg-green-500',
    createdAt: new Date(),
    isActive: true,
  },
];

const mockEmails: Email[] = [
  {
    id: '1',
    from: 'client@example.com',
    to: ['admin@company.com'],
    subject: 'Important Business Proposal',
    body: 'I would like to discuss a potential partnership...',
    date: new Date(),
    accountId: '1',
    isRead: false,
    isStarred: true,
    labels: ['Important', 'Business'],
    attachments: [],
  },
  {
    id: '2',
    from: 'customer@example.com',
    to: ['support@company.com'],
    subject: 'Issue with recent order',
    body: 'I am experiencing problems with my recent order...',
    date: new Date(Date.now() - 300000),
    accountId: '3',
    isRead: false,
    isStarred: false,
    labels: ['Support', 'Priority'],
    attachments: [],
  },
];

const mockTasks: Task[] = [
  {
    id: '1',
    title: 'Review quarterly reports',
    description: 'Analyze Q4 performance metrics',
    assignedTo: 'admin@company.com',
    status: 'pending',
    priority: 'high',
    dueDate: new Date(Date.now() + 86400000),
    createdAt: new Date(),
  },
  {
    id: '2',
    title: 'Update customer database',
    description: 'Sync new customer information',
    assignedTo: 'sales@company.com',
    status: 'in-progress',
    priority: 'medium',
    dueDate: new Date(Date.now() + 172800000),
    createdAt: new Date(),
  },
];

const mockAlerts: Alert[] = [
  {
    id: '1',
    type: 'warning',
    title: 'OAuth Token Expiring',
    message: 'support@company.com OAuth token expires in 2 days',
    timestamp: new Date(),
    isRead: false,
    accountId: '3',
  },
  {
    id: '2',
    type: 'success',
    title: 'Sync Completed',
    message: 'Successfully synced 247 emails from admin@company.com',
    timestamp: new Date(Date.now() - 300000),
    isRead: false,
    accountId: '1',
  },
];

const mockAnalytics: Analytics = {
  totalEmails: 1295,
  todayEmails: 48,
  activeAccounts: 3,
  totalGroups: 2,
  averageResponseTime: 2.4,
  emailsByHour: [
    { hour: 9, count: 12 },
    { hour: 10, count: 18 },
    { hour: 11, count: 24 },
    { hour: 12, count: 15 },
    { hour: 13, count: 8 },
    { hour: 14, count: 22 },
  ],
  topSenders: [
    { email: 'client@example.com', count: 45 },
    { email: 'partner@company.com', count: 32 },
    { email: 'vendor@supply.com', count: 28 },
  ],
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [accounts, setAccounts] = useState<Account[]>(mockAccounts);
  const [groups, setGroups] = useState<Group[]>(mockGroups);
  const [emails, setEmails] = useState<Email[]>(mockEmails);
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);
  const [analytics] = useState<Analytics>(mockAnalytics);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const addAccount = (account: Omit<Account, 'id'>) => {
    const newAccount = {
      ...account,
      id: Date.now().toString(),
    };
    setAccounts(prev => [...prev, newAccount]);
  };

  const updateAccount = (id: string, updates: Partial<Account>) => {
    setAccounts(prev => prev.map(acc => 
      acc.id === id ? { ...acc, ...updates } : acc
    ));
  };

  const deleteAccount = (id: string) => {
    setAccounts(prev => prev.filter(acc => acc.id !== id));
  };

  const addGroup = (group: Omit<Group, 'id'>) => {
    const newGroup = {
      ...group,
      id: Date.now().toString(),
    };
    setGroups(prev => [...prev, newGroup]);
  };

  const updateGroup = (id: string, updates: Partial<Group>) => {
    setGroups(prev => prev.map(group => 
      group.id === id ? { ...group, ...updates } : group
    ));
  };

  const deleteGroup = (id: string) => {
    setGroups(prev => prev.filter(group => group.id !== id));
  };

  const markAsRead = (emailId: string) => {
    setEmails(prev => prev.map(email => 
      email.id === emailId ? { ...email, isRead: true } : email
    ));
  };

  const starEmail = (emailId: string) => {
    setEmails(prev => prev.map(email => 
      email.id === emailId ? { ...email, isStarred: !email.isStarred } : email
    ));
  };

  const addTask = (task: Omit<Task, 'id'>) => {
    const newTask = {
      ...task,
      id: Date.now().toString(),
    };
    setTasks(prev => [...prev, newTask]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, ...updates } : task
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  const markAlertAsRead = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, isRead: true } : alert
    ));
  };

  const value: AppContextType = {
    accounts,
    addAccount,
    updateAccount,
    deleteAccount,
    groups,
    addGroup,
    updateGroup,
    deleteGroup,
    emails,
    markAsRead,
    starEmail,
    tasks,
    addTask,
    updateTask,
    deleteTask,
    alerts,
    markAlertAsRead,
    analytics,
    activeSection,
    setActiveSection,
    sidebarCollapsed,
    setSidebarCollapsed,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}