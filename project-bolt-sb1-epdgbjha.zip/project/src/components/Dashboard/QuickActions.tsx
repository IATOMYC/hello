import React from 'react';
import { Plus, FolderSync as Sync, Mail, Settings, Users, FileText } from 'lucide-react';

const quickActions = [
  {
    title: 'Add New Account',
    description: 'Connect a Gmail account via OAuth',
    icon: Plus,
    color: 'bg-blue-500 hover:bg-blue-600',
    action: 'add-account',
  },
  {
    title: 'Sync All Accounts',
    description: 'Force refresh all connected accounts',
    icon: Sync,
    color: 'bg-green-500 hover:bg-green-600',
    action: 'sync-all',
  },
  {
    title: 'Compose Email',
    description: 'Send email from any connected account',
    icon: Mail,
    color: 'bg-purple-500 hover:bg-purple-600',
    action: 'compose',
  },
  {
    title: 'Create Group',
    description: 'Organize accounts into new group',
    icon: Users,
    color: 'bg-indigo-500 hover:bg-indigo-600',
    action: 'create-group',
  },
  {
    title: 'Generate Report',
    description: 'Export analytics and statistics',
    icon: FileText,
    color: 'bg-yellow-500 hover:bg-yellow-600',
    action: 'generate-report',
  },
  {
    title: 'Manage Settings',
    description: 'Configure automation and filters',
    icon: Settings,
    color: 'bg-gray-500 hover:bg-gray-600',
    action: 'settings',
  },
];

export function QuickActions() {
  const handleAction = (action: string) => {
    console.log(`Executing action: ${action}`);
    // Here you would implement the actual action logic
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Quick Actions</h3>
        <p className="text-sm text-gray-600 mt-1">Common tasks and shortcuts</p>
      </div>
      
      <div className="p-6">
        <div className="space-y-3">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.action}
                onClick={() => handleAction(action.action)}
                className="w-full flex items-center space-x-4 p-3 rounded-lg border border-gray-200 hover:border-gray-300 hover:shadow-sm transition-all text-left"
              >
                <div className={`p-2 rounded-lg ${action.color} text-white`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{action.title}</p>
                  <p className="text-xs text-gray-600">{action.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}