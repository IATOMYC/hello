import React from 'react';
import { Mail, UserPlus, CheckCircle, AlertTriangle, Clock } from 'lucide-react';

const activities = [
  {
    id: 1,
    type: 'email',
    title: 'New email from client@example.com',
    description: 'Important Business Proposal - requires immediate attention',
    timestamp: '2 minutes ago',
    icon: Mail,
    color: 'blue',
  },
  {
    id: 2,
    type: 'account',
    title: 'OAuth token refreshed',
    description: 'sales@company.com successfully reconnected',
    timestamp: '5 minutes ago',
    icon: CheckCircle,
    color: 'green',
  },
  {
    id: 3,
    type: 'alert',
    title: 'Token expiring soon',
    description: 'support@company.com OAuth expires in 2 days',
    timestamp: '10 minutes ago',
    icon: AlertTriangle,
    color: 'yellow',
  },
  {
    id: 4,
    type: 'account',
    title: 'New account added',
    description: 'marketing@company.com joined Management Team group',
    timestamp: '15 minutes ago',
    icon: UserPlus,
    color: 'purple',
  },
];

const iconColors = {
  blue: 'text-blue-600 bg-blue-50',
  green: 'text-green-600 bg-green-50',
  yellow: 'text-yellow-600 bg-yellow-50',
  purple: 'text-purple-600 bg-purple-50',
  red: 'text-red-600 bg-red-50',
};

export function RecentActivity() {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
        <p className="text-sm text-gray-600 mt-1">Latest updates from your Gmail accounts</p>
      </div>
      
      <div className="p-6">
        <div className="space-y-4">
          {activities.map((activity) => {
            const Icon = activity.icon;
            return (
              <div key={activity.id} className="flex items-start space-x-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div className={`p-2 rounded-lg ${iconColors[activity.color as keyof typeof iconColors]}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                  <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <Clock className="w-3 h-3 mr-1" />
                    {activity.timestamp}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        
        <button className="w-full mt-4 text-sm text-blue-600 hover:text-blue-700 font-medium py-2 border-t border-gray-100">
          View All Activity
        </button>
      </div>
    </div>
  );
}