import React from 'react';
import { Mail, Users, CheckSquare, Bell, TrendingUp, Clock } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { StatsCard } from './StatsCard';
import { RecentActivity } from './RecentActivity';
import { QuickActions } from './QuickActions';

export function Dashboard() {
  const { analytics, accounts, groups, tasks, alerts, emails } = useApp();
  
  const unreadEmails = emails.filter(email => !email.isRead).length;
  const pendingTasks = tasks.filter(task => task.status === 'pending').length;
  const unreadAlerts = alerts.filter(alert => !alert.isRead).length;

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 p-8 rounded-2xl text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome to Gmail Management Platform</h1>
        <p className="text-blue-100 text-lg">
          Centrally manage {accounts.length} Gmail accounts across {groups.length} groups with advanced automation
        </p>
        <div className="flex items-center space-x-6 mt-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm">All systems operational</span>
          </div>
          <div className="text-sm">Last sync: 2 minutes ago</div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Emails"
          value={analytics.totalEmails.toLocaleString()}
          change="+12% from yesterday"
          icon={Mail}
          color="blue"
          trend="up"
        />
        <StatsCard
          title="Active Accounts"
          value={analytics.activeAccounts}
          change={`${accounts.filter(acc => acc.isActive).length} connected`}
          icon={Users}
          color="green"
          trend="neutral"
        />
        <StatsCard
          title="Pending Tasks"
          value={pendingTasks}
          change={`${tasks.length - pendingTasks} completed`}
          icon={CheckSquare}
          color="yellow"
          trend="down"
        />
        <StatsCard
          title="Unread Alerts"
          value={unreadAlerts}
          change="2 critical alerts"
          icon={Bell}
          color="red"
          trend="up"
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard
          title="Today's Emails"
          value={analytics.todayEmails}
          change="vs 34 yesterday"
          icon={TrendingUp}
          color="indigo"
          trend="up"
        />
        <StatsCard
          title="Avg Response Time"
          value={`${analytics.averageResponseTime}h`}
          change="-0.3h improvement"
          icon={Clock}
          color="purple"
          trend="down"
        />
        <StatsCard
          title="Unread Messages"
          value={unreadEmails}
          change="Across all accounts"
          icon={Mail}
          color="blue"
          trend="neutral"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <RecentActivity />
        </div>
        
        {/* Quick Actions */}
        <div>
          <QuickActions />
        </div>
      </div>
    </div>
  );
}