import React from 'react';
import { 
  BarChart3, 
  Mail, 
  Users, 
  CheckSquare, 
  Bell, 
  Settings,
  Menu,
  Home,
  UserPlus,
  Inbox,
  ChevronRight,
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';

interface SidebarProps {
  className?: string;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'accounts', label: 'Accounts', icon: UserPlus },
  { id: 'groups', label: 'Groups', icon: Users },
  { id: 'inbox', label: 'Central Inbox', icon: Inbox },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  { id: 'alerts', label: 'Alerts', icon: Bell },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Sidebar({ className = '' }: SidebarProps) {
  const { activeSection, setActiveSection, sidebarCollapsed, setSidebarCollapsed } = useApp();

  return (
    <div className={`bg-white shadow-xl transition-all duration-300 ${sidebarCollapsed ? 'w-16' : 'w-64'} ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className={`flex items-center space-x-3 transition-opacity duration-300 ${sidebarCollapsed ? 'opacity-0' : 'opacity-100'}`}>
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Gmail Manager</h1>
              <p className="text-xs text-gray-500">Professional Platform</p>
            </div>
          </div>
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-1 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                isActive 
                  ? 'bg-blue-50 text-blue-700 border-l-4 border-blue-700' 
                  : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-blue-700' : 'text-gray-500'} transition-colors`} />
              <span className={`font-medium transition-opacity duration-300 ${sidebarCollapsed ? 'opacity-0' : 'opacity-100'}`}>
                {item.label}
              </span>
              {!sidebarCollapsed && isActive && (
                <ChevronRight className="w-4 h-4 text-blue-700 ml-auto" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      {!sidebarCollapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-3 border border-blue-200">
            <p className="text-xs font-semibold text-blue-900 mb-1">Pro Features</p>
            <p className="text-xs text-blue-700">Advanced analytics and unlimited accounts</p>
          </div>
        </div>
      )}
    </div>
  );
}