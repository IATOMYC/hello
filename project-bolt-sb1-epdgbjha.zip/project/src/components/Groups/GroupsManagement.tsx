import React, { useState } from 'react';
import { Users, Plus, Edit2, Trash2, Mail, User } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Group } from '../../types';

export function GroupsManagement() {
  const { groups, accounts, addGroup, updateGroup, deleteGroup } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingGroup, setEditingGroup] = useState<Group | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: 'bg-blue-500',
  });

  const colors = [
    'bg-blue-500',
    'bg-green-500',
    'bg-purple-500',
    'bg-red-500',
    'bg-yellow-500',
    'bg-indigo-500',
    'bg-pink-500',
    'bg-gray-500',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingGroup) {
      updateGroup(editingGroup.id, {
        ...formData,
        accountIds: editingGroup.accountIds, // Preserve existing account assignments
      });
      setEditingGroup(null);
    } else {
      addGroup({
        ...formData,
        accountIds: [],
        createdAt: new Date(),
        isActive: true,
      });
    }
    
    setFormData({ name: '', description: '', color: 'bg-blue-500' });
    setShowAddForm(false);
  };

  const handleEdit = (group: Group) => {
    setEditingGroup(group);
    setFormData({
      name: group.name,
      description: group.description,
      color: group.color,
    });
    setShowAddForm(true);
  };

  const handleDelete = (groupId: string) => {
    if (window.confirm('Are you sure you want to delete this group?')) {
      deleteGroup(groupId);
    }
  };

  const getGroupAccounts = (groupId: string) => {
    return accounts.filter(account => account.groupId === groupId);
  };

  const getTotalMessages = (groupId: string) => {
    const groupAccounts = getGroupAccounts(groupId);
    return groupAccounts.reduce((sum, account) => sum + account.messageCount, 0);
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Groups Management</h1>
          <p className="text-gray-600 mt-1">Organize your Gmail accounts into manageable groups</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Create Group</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total Groups</p>
              <p className="text-3xl font-bold text-gray-900">{groups.length}</p>
            </div>
            <div className="p-3 rounded-xl bg-blue-100">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Active Groups</p>
              <p className="text-3xl font-bold text-green-600">{groups.filter(g => g.isActive).length}</p>
            </div>
            <div className="p-3 rounded-xl bg-green-100">
              <Users className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Avg Accounts/Group</p>
              <p className="text-3xl font-bold text-purple-600">
                {groups.length > 0 ? Math.round(accounts.length / groups.length) : 0}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-purple-100">
              <User className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {groups.map((group) => {
          const groupAccounts = getGroupAccounts(group.id);
          const totalMessages = getTotalMessages(group.id);

          return (
            <div key={group.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
              {/* Header */}
              <div className={`${group.color} p-4 text-white`}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold">{group.name}</h3>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEdit(group)}
                      className="p-1 hover:bg-white/20 rounded"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(group.id)}
                      className="p-1 hover:bg-white/20 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="text-white/80 text-sm">{group.description}</p>
              </div>

              {/* Stats */}
              <div className="p-4">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{groupAccounts.length}</p>
                    <p className="text-xs text-gray-600">Accounts</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-gray-900">{totalMessages.toLocaleString()}</p>
                    <p className="text-xs text-gray-600">Messages</p>
                  </div>
                </div>

                {/* Accounts List */}
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700 flex items-center">
                    <Mail className="w-4 h-4 mr-1" />
                    Accounts
                  </h4>
                  {groupAccounts.length > 0 ? (
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {groupAccounts.map((account) => (
                        <div key={account.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <div className="w-6 h-6 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-medium">
                              {account.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <p className="text-xs font-medium text-gray-900 truncate max-w-32">{account.email}</p>
                            </div>
                          </div>
                          <div className={`w-2 h-2 rounded-full ${account.isActive ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 italic">No accounts assigned</p>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="px-4 py-3 bg-gray-50 text-xs text-gray-500">
                Created {new Date(group.createdAt).toLocaleDateString()}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add/Edit Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-md">
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {editingGroup ? 'Edit Group' : 'Create New Group'}
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Group Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={3}
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Color Theme
                </label>
                <div className="flex space-x-2">
                  {colors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, color }))}
                      className={`w-8 h-8 rounded-lg ${color} ${
                        formData.color === color ? 'ring-2 ring-gray-400' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-3 mt-6">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {editingGroup ? 'Update Group' : 'Create Group'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingGroup(null);
                    setFormData({ name: '', description: '', color: 'bg-blue-500' });
                  }}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-400 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}