import React from 'react';
import { BarChart3, TrendingUp, Mail, Clock, User, Calendar } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';

export function AnalyticsDashboard() {
  const { analytics, accounts } = useApp();

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="text-gray-600 mt-1">Detailed insights and performance metrics</p>
        </div>
        <div className="flex items-center space-x-2">
          <BarChart3 className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-medium text-gray-600">
            Real-time Analytics
          </span>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium mb-2">Total Emails</p>
              <p className="text-3xl font-bold">{analytics.totalEmails.toLocaleString()}</p>
              <p className="text-blue-100 text-sm mt-1">All time</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg">
              <Mail className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium mb-2">Today's Emails</p>
              <p className="text-3xl font-bold">{analytics.todayEmails}</p>
              <p className="text-green-100 text-sm mt-1">+23% vs yesterday</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-xl text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium mb-2">Active Accounts</p>
              <p className="text-3xl font-bold">{analytics.activeAccounts}</p>
              <p className="text-purple-100 text-sm mt-1">of {accounts.length} total</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg">
              <User className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-yellow-500 to-yellow-600 p-6 rounded-xl text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-100 text-sm font-medium mb-2">Avg Response Time</p>
              <p className="text-3xl font-bold">{analytics.averageResponseTime}h</p>
              <p className="text-yellow-100 text-sm mt-1">-0.3h from last week</p>
            </div>
            <div className="p-3 bg-white/20 rounded-lg">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Email Activity Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Email Activity by Hour</h3>
            <Calendar className="w-5 h-5 text-gray-600" />
          </div>
          
          <div className="space-y-4">
            {analytics.emailsByHour.map((data) => (
              <div key={data.hour} className="flex items-center">
                <span className="w-12 text-sm text-gray-600">{data.hour}:00</span>
                <div className="flex-1 mx-4">
                  <div className="h-6 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full transition-all duration-500"
                      style={{ width: `${(data.count / Math.max(...analytics.emailsByHour.map(d => d.count))) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <span className="w-8 text-sm font-medium text-gray-900">{data.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Senders */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Top Senders</h3>
            <User className="w-5 h-5 text-gray-600" />
          </div>
          
          <div className="space-y-4">
            {analytics.topSenders.map((sender, index) => (
              <div key={sender.email} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white text-xs font-medium">
                    {index + 1}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{sender.email}</p>
                    <p className="text-xs text-gray-500">{sender.count} emails</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"
                      style={{ width: `${(sender.count / Math.max(...analytics.topSenders.map(s => s.count))) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs font-medium text-gray-600 mt-1">{sender.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Account Performance */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Account Performance</h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Messages</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Sync</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Performance</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {accounts.map((account) => {
                const performance = Math.floor(Math.random() * 40) + 60; // Mock performance score
                return (
                  <tr key={account.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-medium">
                          {account.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{account.name}</div>
                          <div className="text-sm text-gray-500">{account.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {account.messageCount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        account.oauthStatus === 'connected' ? 'bg-green-100 text-green-800' :
                        account.oauthStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {account.oauthStatus}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(account.lastSync).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden mr-2">
                          <div
                            className={`h-full rounded-full ${
                              performance >= 80 ? 'bg-green-500' :
                              performance >= 60 ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}
                            style={{ width: `${performance}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900">{performance}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}