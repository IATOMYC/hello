import React from 'react';
import { AlertTriangle, CheckCircle, Info, X, Bell, Clock } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Alert } from '../../types';

export function AlertsCenter() {
  const { alerts, markAlertAsRead } = useApp();

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'error':
        return <X className="w-5 h-5 text-red-500" />;
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getAlertColor = (type: Alert['type']) => {
    switch (type) {
      case 'success':
        return 'border-l-green-500 bg-green-50';
      case 'warning':
        return 'border-l-yellow-500 bg-yellow-50';
      case 'error':
        return 'border-l-red-500 bg-red-50';
      default:
        return 'border-l-blue-500 bg-blue-50';
    }
  };

  const unreadAlerts = alerts.filter(alert => !alert.isRead);
  const readAlerts = alerts.filter(alert => alert.isRead);

  const alertStats = {
    total: alerts.length,
    unread: unreadAlerts.length,
    critical: alerts.filter(a => a.type === 'error').length,
    warnings: alerts.filter(a => a.type === 'warning').length,
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Alerts Center</h1>
          <p className="text-gray-600 mt-1">Monitor system notifications and account alerts</p>
        </div>
        <div className="flex items-center space-x-2">
          <Bell className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-medium text-gray-600">
            {unreadAlerts.length} new alerts
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Total Alerts</p>
              <p className="text-3xl font-bold text-gray-900">{alertStats.total}</p>
            </div>
            <div className="p-3 rounded-xl bg-gray-100">
              <Bell className="w-6 h-6 text-gray-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Unread</p>
              <p className="text-3xl font-bold text-blue-600">{alertStats.unread}</p>
            </div>
            <div className="p-3 rounded-xl bg-blue-100">
              <Info className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Critical</p>
              <p className="text-3xl font-bold text-red-600">{alertStats.critical}</p>
            </div>
            <div className="p-3 rounded-xl bg-red-100">
              <X className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 mb-2">Warnings</p>
              <p className="text-3xl font-bold text-yellow-600">{alertStats.warnings}</p>
            </div>
            <div className="p-3 rounded-xl bg-yellow-100">
              <AlertTriangle className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-6">
        {/* Unread Alerts */}
        {unreadAlerts.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                New Alerts ({unreadAlerts.length})
              </h3>
            </div>
            
            <div className="divide-y divide-gray-100">
              {unreadAlerts.map((alert) => (
                <div key={alert.id} className={`p-6 border-l-4 ${getAlertColor(alert.type)}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getAlertIcon(alert.type)}
                      <div className="flex-1">
                        <h4 className="text-lg font-medium text-gray-900 mb-1">
                          {alert.title}
                        </h4>
                        <p className="text-gray-600 mb-3">{alert.message}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>{new Date(alert.timestamp).toLocaleString()}</span>
                          </div>
                          {alert.accountId && (
                            <span className="text-blue-600">
                              Account ID: {alert.accountId}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <button
                      onClick={() => markAlertAsRead(alert.id)}
                      className="ml-4 px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 transition-colors"
                    >
                      Mark as Read
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Read Alerts */}
        {readAlerts.length > 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <CheckCircle className="w-5 h-5 mr-2 text-gray-600" />
                Previous Alerts ({readAlerts.length})
              </h3>
            </div>
            
            <div className="divide-y divide-gray-100 max-h-96 overflow-y-auto">
              {readAlerts.map((alert) => (
                <div key={alert.id} className="p-6 opacity-75 hover:opacity-100 transition-opacity">
                  <div className="flex items-start space-x-3">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <h4 className="text-lg font-medium text-gray-900 mb-1">
                        {alert.title}
                      </h4>
                      <p className="text-gray-600 mb-3">{alert.message}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{new Date(alert.timestamp).toLocaleString()}</span>
                        </div>
                        {alert.accountId && (
                          <span className="text-blue-600">
                            Account ID: {alert.accountId}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {alerts.length === 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 text-center py-12">
            <CheckCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No alerts at this time. All systems running smoothly!</p>
          </div>
        )}
      </div>
    </div>
  );
}