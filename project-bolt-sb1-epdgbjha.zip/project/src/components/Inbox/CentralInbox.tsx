import React, { useState } from 'react';
import { Search, Filter, Star, Mail, Paperclip, Reply, Forward, Archive, Trash2 } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Email } from '../../types';

export function CentralInbox() {
  const { emails, accounts, markAsRead, starEmail } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterAccount, setFilterAccount] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedEmails, setSelectedEmails] = useState<string[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);

  const filteredEmails = emails.filter(email => {
    const matchesSearch = email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         email.from.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesAccount = filterAccount === 'all' || email.accountId === filterAccount;
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'unread' && !email.isRead) ||
                         (filterStatus === 'starred' && email.isStarred);
    return matchesSearch && matchesAccount && matchesStatus;
  });

  const getAccountName = (accountId: string) => {
    const account = accounts.find(a => a.id === accountId);
    return account?.email || 'Unknown Account';
  };

  const handleEmailSelect = (emailId: string) => {
    if (selectedEmails.includes(emailId)) {
      setSelectedEmails(selectedEmails.filter(id => id !== emailId));
    } else {
      setSelectedEmails([...selectedEmails, emailId]);
    }
  };

  const handleEmailClick = (email: Email) => {
    setSelectedEmail(email);
    if (!email.isRead) {
      markAsRead(email.id);
    }
  };

  const handleBulkAction = (action: string) => {
    console.log(`Bulk action: ${action} on emails:`, selectedEmails);
    setSelectedEmails([]);
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Central Inbox</h1>
          <p className="text-gray-600 mt-1">All emails from connected accounts in one place</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search emails..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full"
            />
          </div>
          
          <div className="flex items-center space-x-4">
            <select
              value={filterAccount}
              onChange={(e) => setFilterAccount(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Accounts</option>
              {accounts.map(account => (
                <option key={account.id} value={account.id}>{account.email}</option>
              ))}
            </select>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Emails</option>
              <option value="unread">Unread</option>
              <option value="starred">Starred</option>
            </select>
          </div>
        </div>

        {/* Bulk Actions */}
        {selectedEmails.length > 0 && (
          <div className="flex items-center space-x-2 mt-4 p-3 bg-blue-50 rounded-lg">
            <span className="text-sm font-medium text-blue-900">
              {selectedEmails.length} email(s) selected
            </span>
            <div className="flex items-center space-x-2 ml-4">
              <button
                onClick={() => handleBulkAction('archive')}
                className="flex items-center space-x-1 px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700"
              >
                <Archive className="w-4 h-4" />
                <span>Archive</span>
              </button>
              <button
                onClick={() => handleBulkAction('delete')}
                className="flex items-center space-x-1 px-3 py-1 bg-red-600 text-white text-sm rounded-md hover:bg-red-700"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Email List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email List Panel */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-900">
                Emails ({filteredEmails.length})
              </h3>
            </div>
            
            <div className="divide-y divide-gray-100 max-h-96 overflow-y-auto">
              {filteredEmails.map((email) => (
                <div
                  key={email.id}
                  className={`p-4 hover:bg-gray-50 cursor-pointer transition-colors ${
                    !email.isRead ? 'bg-blue-50/50' : ''
                  }`}
                  onClick={() => handleEmailClick(email)}
                >
                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      checked={selectedEmails.includes(email.id)}
                      onChange={() => handleEmailSelect(email.id)}
                      onClick={(e) => e.stopPropagation()}
                      className="mt-1"
                    />
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className={`text-sm truncate ${!email.isRead ? 'font-semibold text-gray-900' : 'text-gray-700'}`}>
                          {email.from}
                        </p>
                        <div className="flex items-center space-x-2">
                          {email.attachments.length > 0 && (
                            <Paperclip className="w-4 h-4 text-gray-400" />
                          )}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              starEmail(email.id);
                            }}
                            className={`${email.isStarred ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-500'}`}
                          >
                            <Star className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      <p className={`text-sm mb-2 ${!email.isRead ? 'font-medium text-gray-900' : 'text-gray-600'}`}>
                        {email.subject}
                      </p>
                      
                      <p className="text-xs text-gray-500 truncate">
                        {email.body.substring(0, 100)}...
                      </p>
                      
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded-full">
                          {getAccountName(email.accountId)}
                        </span>
                        <span className="text-xs text-gray-500">
                          {new Date(email.date).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {filteredEmails.length === 0 && (
              <div className="text-center py-12">
                <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No emails found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Email Detail Panel */}
        <div className="lg:col-span-1">
          {selectedEmail ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Email Details</h3>
                  <div className="flex items-center space-x-2">
                    <button className="p-1 text-gray-600 hover:text-blue-600">
                      <Reply className="w-4 h-4" />
                    </button>
                    <button className="p-1 text-gray-600 hover:text-blue-600">
                      <Forward className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-4 space-y-4">
                <div>
                  <p className="text-sm text-gray-600">From</p>
                  <p className="font-medium text-gray-900">{selectedEmail.from}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600">To</p>
                  <p className="font-medium text-gray-900">{selectedEmail.to.join(', ')}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600">Account</p>
                  <p className="font-medium text-blue-600">{getAccountName(selectedEmail.accountId)}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600">Subject</p>
                  <p className="font-medium text-gray-900">{selectedEmail.subject}</p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600">Date</p>
                  <p className="font-medium text-gray-900">
                    {new Date(selectedEmail.date).toLocaleString()}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm text-gray-600">Message</p>
                  <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-700">{selectedEmail.body}</p>
                  </div>
                </div>
                
                {selectedEmail.labels.length > 0 && (
                  <div>
                    <p className="text-sm text-gray-600 mb-2">Labels</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedEmail.labels.map((label) => (
                        <span
                          key={label}
                          className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                        >
                          {label}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center">
              <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">Select an email to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}