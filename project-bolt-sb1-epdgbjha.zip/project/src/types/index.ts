// Core Types for Gmail Management Platform

export interface GmailAccount {
  id: string;
  email: string;
  displayName: string;
  isActive: boolean;
  lastSync: Date;
  status: 'connected' | 'error' | 'syncing';
  groupId: string;
  unreadCount: number;
  totalEmails: number;
  oauthToken?: string;
  refreshToken?: string;
}

export interface AccountGroup {
  id: string;
  name: string;
  description: string;
  color: string;
  accounts: string[]; // account IDs
  isActive: boolean;
  createdAt: Date;
  settings: GroupSettings;
}

export interface GroupSettings {
  forwardToCentral: boolean;
  autoReply: boolean;
  autoReplyMessage?: string;
  filters: EmailFilter[];
  customRules: Rule[];
}

export interface EmailFilter {
  id: string;
  name: string;
  criteria: FilterCriteria;
  actions: FilterAction[];
  isActive: boolean;
}

export interface FilterCriteria {
  sender?: string;
  subject?: string;
  contains?: string;
  dateRange?: DateRange;
  hasAttachment?: boolean;
}

export interface FilterAction {
  type: 'label' | 'forward' | 'archive' | 'delete' | 'markRead';
  value?: string;
}

export interface DateRange {
  from: Date;
  to: Date;
}

export interface Rule {
  id: string;
  name: string;
  condition: string;
  action: string;
  isActive: boolean;
}

export interface Email {
  id: string;
  threadId: string;
  accountId: string;
  from: string;
  to: string[];
  subject: string;
  snippet: string;
  body?: string;
  date: Date;
  isRead: boolean;
  isStarred: boolean;
  labels: string[];
  hasAttachment: boolean;
  attachments?: Attachment[];
}

export interface Attachment {
  id: string;
  filename: string;
  mimeType: string;
  size: number;
  data?: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  assignedTo?: string;
  dueDate?: Date;
  createdAt: Date;
  updatedAt: Date;
  tags: string[];
  relatedEmails?: string[];
}

export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  accountId?: string;
  groupId?: string;
  isRead: boolean;
  createdAt: Date;
  priority: 'low' | 'medium' | 'high';
}

export interface Analytics {
  totalAccounts: number;
  activeAccounts: number;
  totalEmails: number;
  unreadEmails: number;
  emailsByDay: { date: string; count: number }[];
  topSenders: { email: string; count: number }[];
  accountActivity: { accountId: string; activity: number }[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'user';
  permissions: Permission[];
  createdAt: Date;
  lastLogin: Date;
}

export interface Permission {
  action: string;
  resource: string;
  conditions?: any;
}

export interface NavSection {
  id: string;
  name: string;
  icon: string;
  component: string;
  isVisible: boolean;
  order: number;
  permissions?: string[];
}